import React, { useState, useEffect, useRef } from 'react';
import Navbar from './Componet/Navbar';
import { Route, Routes } from "react-router-dom";
import Footer from './Componet/Footer';
import Login from './Componet/Popup/Login.jsx';
import Signup from './Componet/Popup/Signup.jsx';
import Cardslider from './Componet/Cardslider.jsx';
import Coursepage from './Componet/Coursepage.jsx';
import './App.css';
import Contact from './Componet/Contact.jsx';
import Quiz from './Componet/Quiz.jsx';
import { CourseProvider } from './Componet/CourseContext.jsx';
import UserProfile from './Componet/UserProfile.jsx';
import LoginFinal from './Componet/LoginFinal.jsx';
import SignupFinal from './Componet/SignupFinal.jsx';
function App() {
  const [showCoursePage, setShowCoursePage] = useState(false);
  
  const targetRef = useRef(null);

  const handleBuyClick = () => {
    setShowCoursePage(true);
  };

  const handleGoBack = () => {
    setShowCoursePage(false);
  };


 
  const onGoBack = () => {
    setShowCoursePage(false);
    // console.log('hii');
  };


  return (
    <>
      <Navbar  scrollToTarget={targetRef}/>
     
      {/* <CourseProvider>
        <Routes>

          <Route
            path='/'
            element={<Cardslider targetRef={targetRef}  onButtonClick={handleBuyClick} />}
          />
          <Route
            path='/contact'
            element={<Contact targetRef={targetRef} />}
          />
          <Route
            path='/login'
            element={<Login />}
          />
          <Route
            path='/signup'
            element={<Signup />}
          />
          <Route
            path='/coursepage'
            element={<Coursepage targetRef={targetRef} />}
          />
          <Route
            path='/quiz'
            element={<Quiz />}
          />
           <Route
            path='/userprofile'
            element={<UserProfile/>}
          />
          <Route
            path='/loginfinal'
            element={ <LoginFinal/>}
          />
          <Route
            path='/signupfinal'
            element={ <SignupFinal/>}
          />
        
        </Routes>
      </CourseProvider>
      <Footer /> */}
      {/* <LoginFinal/> */}
      <SignupFinal/>

    </>
  );
}

export default App;
