import React, { useState, useEffect } from 'react';

import './Quiz.css'
const Quiz = () => {
 
  return (
    <>
      <div className="quiz-img">
      <img src={require('../img/quiz.jpg')} alt={'example'} id='quiz'/>
               <h1>Quiz is Coming Soon ...</h1>   
      </div>
      
     
    </>
  );
}

export default Quiz;
