
// import React, { useState, useEffect } from 'react';
// import './Contact.css';
// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
// import { faUser, faEnvelope, faPhone, faMapMarkerAlt, faEye, faEyeSlash } from '@fortawesome/free-solid-svg-icons';
// import { faTelegram } from '@fortawesome/free-brands-svg-icons';

// const Contact = () => {
//   const [isPassShow, setPassShow] = useState(false);
//   const [passType, setPassType] = useState('password');
//   const [fadeIn, setFadeIn] = useState(false);


//   const passShowHide = () => {
//     setPassShow(!isPassShow);
//     setPassType((prevType) => (prevType === "password" ? "text" : "password"));
//   }

//   const [formData, setFormData] = useState({
//     username: '',
//     fullname: '',
//     password: '',
//     email: '',
//     phone: '',
//   });

//   const handleButtonClick = () => {
//     console.log('Form data submitted:', formData);
//   }

//   return (
//     <>
//       <div  className={`contact-container ${fadeIn ? 'fade-in' : ''}`}>
//         <iframe
//           src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3784.507195859286!2d73.85519627404464!3d18.46067127100344!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc2eaa50b010a4d%3A0x825a7eb297bf3ff2!2sAxis%20Bank%20Branch!5e0!3m2!1sen!2sin"
//           width="100%"
//           height="310"
//           style={{ border: "30" }}
//           allowFullScreen="100%"
//           loading="lazy"
//           referrerPolicy="no-referrer-when-downgrade"
//         ></iframe>
//         <div className="dymcs">
//           <div className='contact-drop'>
//             <div className={`message-section box ${fadeIn ? 'fade-in' : ''}`}>
//               <h2 className="marquee">Drop Your Message</h2>
//               <div className="input-icons">
//                 <label>
//                   <FontAwesomeIcon icon={faUser} className="icon" />
//                   <input
//                     className='opt8 input-field'
//                     type="text"
//                     placeholder="Enter Username"
//                     value={formData.username}
//                     onChange={(e) => setFormData({ ...formData, username: e.target.value })}
//                   />
//                 </label>
//               </div>

//               <div className="input-icons">
//                 <label>
//                   <FontAwesomeIcon icon={faUser} className="icon" />
//                   <input
//                     className='opt8 input-field'
//                     type="text"
//                     placeholder="Enter Fullname"
//                     value={formData.fullname}
//                     onChange={(e) => setFormData({ ...formData, fullname: e.target.value })}
//                   />
//                 </label>
//               </div>

//               <div className="input-icons">
//                 <label>
//                   <FontAwesomeIcon icon={isPassShow ? faEye : faEyeSlash} className="icon" onClick={passShowHide} />
//                   <input
//                     className='opt8 input-field'
//                     type={passType}
//                     placeholder="Enter Password"
//                     value={formData.password}
//                     onChange={(e) => setFormData({ ...formData, password: e.target.value })}
//                   />
//                 </label>
//               </div>

//               <div className="input-icons">
//                 <label>
//                   <FontAwesomeIcon icon={faEnvelope} className="icon" />
//                   <input
//                     className='opt8 input-field'
//                     type="email"
//                     placeholder="Enter Email"
//                     value={formData.email}
//                     onChange={(e) => setFormData({ ...formData, email: e.target.value })}
//                   />
//                 </label>
//               </div>

//               <div className="input-icons">
//                 <label>
//                   <FontAwesomeIcon icon={faPhone} className="icon" />
//                   <input
//                     className='opt8 input-field'
//                     type="text"
//                     placeholder="+91 999999999"
//                     value={formData.phone}
//                     onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
//                   />
//                 </label>
//               </div>

//               <button type="submit" className={`btn ${fadeIn ? 'fade-in' : ''}`} onClick={handleButtonClick}>
//                 <FontAwesomeIcon icon={faTelegram} className="telegram-icon" />
//                 Submit
//               </button>
//             </div>
//           </div>

//           <div className="contact-info1">
//             <div className="contact-box1">
//               <h2>Contact Us</h2>
//               <div className="office">
//                 <div>
//                   <FontAwesomeIcon icon={faMapMarkerAlt} />
//                   <h3>Office 1: SMiT Solutions</h3>
//                   <p>
//                     Address: Kale Building Kashinath Patil Nagar,
//                     <br />
//                     Behind Axis Bank,
//                     <br />
//                     Dhankawadi Pune
//                   </p>
//                 </div>
//               </div>
//               <div className="office">
//                 <div>
//                   <FontAwesomeIcon icon={faMapMarkerAlt} />
//                   <h3>Office 2: Solapurmall Technology</h3>
//                   <p>
//                     Address: 23 B Rangraj Nagar,
//                     <br />
//                     Behind Market Yard, Solapur
//                   </p>
//                 </div>
//               </div>
//               <div className="contact-details">
//                 <p>
//                   <FontAwesomeIcon icon={faPhone} /> +7385111191
//                 </p>
//                 <p>
//                   <FontAwesomeIcon icon={faPhone} /> 0217 2370239
//                 </p>
//                 <p>
//                   <FontAwesomeIcon icon={faEnvelope} /> rdlomte@gmail.com
//                 </p>
//                 <p>
//                   <FontAwesomeIcon icon={faEnvelope} /> lomatedinesh@gmail.com
//                 </p>
//               </div>
//             </div>

//           </div>
//         </div>
//       </div>
//     </>
//   );
// }

// export default Contact;



import React, { useState, useEffect } from 'react';
import './Contact.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUser, faEnvelope, faPhone, faMapMarkerAlt } from '@fortawesome/free-solid-svg-icons';
import { faTelegram } from '@fortawesome/free-brands-svg-icons';

function Contact() {
  const [isPassShow, setPassShow] = useState(false);
  const [passType, setPassType] = useState('password');
  const [fadeIn, setFadeIn] = useState(false);

  const passShowHide = () => {
    setPassShow(!isPassShow);
    setPassType((prevType) => (prevType === "password" ? "text" : "password"));
  }

  const [formData, setFormData] = useState({
    username: '',
    fullname: '',
    password: '',
    email: '',
    phone: '',
  });

  const handleButtonClick = () => {
    console.log('Form data submitted:', formData);
  }

  return (
    <div className={`contact-container ${fadeIn ? 'fade-in' : ''}`}>
      <div className='contact-drop'>
        <div className={`message-section box ${fadeIn ? 'fade-in' : ''}`}>
          <h2>Contact Us</h2>
          <div className="office">
            <div>
              <FontAwesomeIcon icon={faMapMarkerAlt} />
              <h3>Office 2: Solapurmall Technology</h3>
              <p>
                Address: 23 B Rangraj Nagar,
               
                Behind Market Yard, Solapur
              </p>
            </div>
          </div>
          <div className="contact-details">
            <p>
              <FontAwesomeIcon icon={faPhone} /> +7385111191
            </p>
            <p>
              <FontAwesomeIcon icon={faPhone} /> 0217 2370239
            </p>
            <p>
              <FontAwesomeIcon icon={faEnvelope} /> lomatedinesh@gmail.com
            </p>
            <h2 className="marquee">Drop Your Message</h2>
            <div className="input-icons">
             
                
                <inputs
                  placeholder="Enter Fullname"
                  value={formData.fullname}
                  onChange={(e) => setFormData({ ...formData, fullname: e.target.value })}
                />
             
            </div>
            <div className="input-icons">
             
                
                <input
                  placeholder="Enter Email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                />
            
            </div>
            <div className="input-icons">
             
               
                <input
                  placeholder="+91 999999999"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                />
             
            </div>
            <button type="submit" className={`btn12 ${fadeIn ? 'fade-in' : ''}`} onClick={handleButtonClick}>
              <FontAwesomeIcon icon={faTelegram} className="telegram-icon" />
              Submit
            </button>
          </div>
        </div>
      </div>
      <iframe
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3784.507195859286!2d73.85519627404464!3d18.46067127100344!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc2eaa50b010a4d%3A0x825a7eb297bf3ff2!2sAxis%20Bank%20Branch!5   e0!3m2!1sen!2sin"
        style={{ border: "30" }}
        allowFullScreen="100%"
        loading="lazy"
        referrerPolicy="no-referrer-when-downgrade"
      ></iframe>
    </div>
  );
}

export default Contact;



