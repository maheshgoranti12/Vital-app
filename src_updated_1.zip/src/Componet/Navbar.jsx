import React, { useEffect, useState, useRef } from 'react';
import './Navbar.css';
import './Fonts.css';
import { CgClose, CgMenu } from "react-icons/cg";
import { useNavigate } from "react-router-dom";
import { Link } from 'react-router-dom';
// import UserLoginLogo from './UserLoginLogo';

export default function Navbar({ onFormLoginToggle, onFormSignUpToggle, scrollToTarget, onGoBack }) {

  // const [isUserLogin, setIsUserLogin] = useState(false);
  // const handleUserLogin = () => {
  //   setIsUserLogin(true);
  // };
  // const handleUserLogout = () => {
  //   setIsUserLogin(false);
  // };
  const navigate = useNavigate();
  const goToCourse = () => {
    navigate("/");
  };
 

  const handleButtonClicked = () => {
    // Scroll to the target element when the button is clicked
    scrollToTarget.current.scrollIntoView({ behavior: 'smooth' });

  };
  const navLinkElsRef = useRef(null);

  const handleCourse = () => {
    goToCourse();
    handleButtonClicked();
  };
  useEffect(() => {
    const navLinkEls = navLinkElsRef.current.querySelectorAll('.nav_link');
    const windowPathname = window.location.pathname;

    navLinkEls.forEach(navLinkEl => {
      if (navLinkEl.getAttribute('href') === windowPathname) {
        navLinkEl.classList.add('active');
      }
    });
  }, []);


  const [isOpen, setIsOpen] = useState(false);
  const toggleMenu = () => {
    setIsOpen(!isOpen);
  }
  const toggleClose = () => {
    setIsOpen(false);
  }



  const [isSticky, setIsSticky] = useState(false);

  useEffect(() => {

    const handleScroll = () => {
      if (window.scrollY > 100) {

        setIsSticky(true);
      } else {

        setIsSticky(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  
  // ${isSticky ? 'sticky' : ''} 
  return (
    <>
      <nav className={`navbar`} >
        <div className="logo">

          <Link to='/'><img className='img1' src={require('../img/logo.png')} alt="Logo" /></Link>
          <Link to='/'><img className='img2' src={require('../img/Vitalcode.png')} alt="Logo" /></Link>
        </div>
        {/* style={{ width: width, transition: 'width 2s' }} */}
        <div className="sidebar " >
          <div className="topsection">

            <div className="bars">
              {!isOpen ? (<CgMenu onClick={toggleMenu} />) : (<CgClose onClick={toggleClose} />)}

            </div>
          </div>


          <div className={`tabs ${isOpen ? 'open' : ''}`} >

            <li><Link to='/quiz' className='link' id='Quiz'>Quiz</Link></li>

            <li><Link to='/contact' id='Contact' className='link' ref={navLinkElsRef}>Contact</Link></li>

            <li><Link to="/loginfinal"><button type="button" className="btn btn-outline link" id='Login'>
              Log in</button></Link></li>

            <li><Link to="/signupfinal"><button type="button" className="btn link" id='Signup'>Sign up
            </button></Link></li>

          </div>


        </div>


      </nav>

    </>

  )

};

