import React from 'react';
import './SignupFinal.css';
import './Popup/Font1.css';
import { FaUser } from "react-icons/fa";
import { RiLockPasswordFill } from "react-icons/ri";
import { MdOutlineEmail } from "react-icons/md";
import { FaPhone } from "react-icons/fa6";
const SignupFinal = () => {
    return (
        <>
            <div className="final_signup">
                <div className="left_signup">
                </div>
                <div className="right_signup">
                    <div className="left_signup_logo">
                        <img className='border_logo' src={require('../img/border_logo_2.png')} alt="border_logo" />
                        <h1>Vitalcode</h1>
                        <h5>EXPLORE THE INTERNALS</h5>
                    </div>
                    <div className="right_form_signup">
                        <form>
                            <h1>Sign Up</h1>
                            <div className="form_content_signup">
                                <label>Full Name </label><br />
                                <div className="sign_wrapper">
                                    <div className="sign_icon"><FaUser className='FaUser' /></div>
                                    <input type="text" className='signup_fullname' />
                                </div>
                                <label>username </label><br />
                                <div className="sign_wrapper">
                                    <div className="sign_icon"> <FaUser className='FaUser' /></div>
                                    <input type="text" className='signup_user' />
                                </div>
                                <label>password</label><br />
                                <div className="sign_wrapper">
                                    <div className="sign_icon"> <RiLockPasswordFill className='RiLockPasswordFill' /></div>
                                    <input type="password" className='signup_pass' />
                                </div>
                                <label>Email</label><br />
                                <div className="sign_wrapper">
                                    <div className="sign_icon"><MdOutlineEmail className='MdOutlineEmail ' /></div>
                                    <input type="email" className='signup_email' />
                                </div>
                                <label>Mobile Number</label><br />
                                <div className="sign_wrapper">
                                    <div className="sign_icon"><FaPhone className='FaPhone ' /></div>
                                    <input type="text" className='signup_mobile' />
                                </div>
                                <br />
                                <button className='button_signup'>Sign Up</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </>
    );
}

export default SignupFinal;
