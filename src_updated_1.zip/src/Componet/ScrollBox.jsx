import React, { useEffect, useState } from 'react';
import './ScrollBox.css';
import Login from './Popup/Login.jsx';
import Signup from './Popup/Signup.jsx';
import { useCourse } from './CourseContext.jsx';// Import the useCourse hook
const ScrollBox = ({ onClose, onSwitch }) => {

  const { selectedCourse, imageSrc } = useCourse(); // Use the useCourse hook to access context
  const [showCoursePage, setShowCoursePage] = useState(false);
  const [isSignUpOpen, setIsSignUpOpen] = useState(false);
  const [isLoginOpen, setIsLoginOpen] = useState(false);

  const handleSwitchToSignUP = () => {
    setIsLoginOpen(false);
    setIsSignUpOpen(true);
  };
  const handleSwitchToLogin = () => {
    setIsLoginOpen(true);
    setIsSignUpOpen(false);
  };
  const handleLogin = () => {
    if (isLoginOpen) {
      // User is logged in, proceed with enrollment or any other action
      // For now, let's just hide the CoursePage
      setShowCoursePage(false);
    } else {
      // User is not logged in, show the login component
      // You may want to customize this part based on your login component structure
      // Here, I'm just toggling the visibility of the login component
      setIsLoginOpen(true);
    }
  };


  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const threshold = window.innerWidth > 768 ? 100 : 500;
      const scrollTop = window.scrollY || document.documentElement.scrollTop;

      if (scrollTop > threshold) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };

    window.addEventListener('scroll', handleScroll);

    // Cleanup the event listener on component unmount
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <div id="scrollBox" className={isVisible ? '' : 'hidden'}>
      <div className={`card-bx1 `} >
        <div className="row">
          <div className="col-md-4" id='cm5'>
            <img src={imageSrc} alt="error" className='mmp1' />
          </div>
          <div className="col-md-7">
            <div className="card-bdy1">
              <h5 className="card-tle2">
                {selectedCourse?.title || 'Course Title'} 
                {/* (Duration
                {selectedCourse?.duration || 'Duration'}) */}
              </h5>

              <h5 className='cd-pmt4'>₹{selectedCourse?.price || 'Price'}/-<br/> (50%-off)</h5>
              <button className="buy-now4" onClick={handleLogin}>
                <p className='enroll5'>Enroll Now</p>
              </button>
            </div>
            {isLoginOpen && <Login onClose={() => setIsLoginOpen(false)} onSwitch={handleSwitchToSignUP} />}
            {isSignUpOpen && <Signup onClose={() => setIsSignUpOpen(false)} onSwitch={handleSwitchToLogin} />}

          </div>
        </div>
      </div>
    </div>
  );
};

export default ScrollBox;
