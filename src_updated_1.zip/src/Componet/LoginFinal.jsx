import React from 'react';
import './LoginFinal.css';
import './Popup/Font1.css';
import { FaUser } from "react-icons/fa";
import { RiLockPasswordFill } from "react-icons/ri";
const LoginFinal = () => {
    return (
        <>
            <div className="final_log">
                <div className="left_log">
                </div>
                <div className="right_log">
                    <div className="left_logo">
                        <img className='border_logo_log' src={require('../img/border_logo_2.png')} alt="border_logo" />
                        <h1>Vitalcode</h1>
                        <h5>EXPLORE THE INTERNALS</h5>
                    </div>
                    <div className="right_form">
                        <form>
                            <h1>Log In</h1>
                            <div className="form_content">
                                <label>username </label><br />
                                <div className="log_wrapper">
                                    <div className="log_icon"><FaUser className='FaUser' /></div>
                                    <input type="text" className='log_user' />
                                </div>
                                <label>password</label><br />
                                <div className="log_wrapper">
                                    <div className="log_icon"><RiLockPasswordFill className='RiLockPasswordFill' /></div>
                                    <input type="password" className='log_pass' />
                                </div>
                                <label>forgot password ?</label>
                                <br /><br />

                                <button className='button_log'>Log In</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

        </>
    );
}

export default LoginFinal;
