import React, { useState } from 'react';
import './EmailVerification.css';
import './Font1.css';

const EmailVerification = ({ onClose, onSwitch }) => {
  return (
    <>
       <div className="overlay">
        <div className="login-form">
          <button className="close-button" onClick={onClose}>
            &times;
          </button>
          <div className="box">
            <h1>Verify your email address</h1>
            <h4>varification link has been sent to vinay@gmail.com.</h4>
            <h5>Please Confirm that you want to use this as your Vital account email address. Once it's done you will be able to start Codding!</h5>
          </div>
        </div>
      </div>
    </>
  );
}

export default EmailVerification;
