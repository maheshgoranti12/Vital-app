
import React, { useState } from 'react';
import './Signup.css';
import './Login.css';
import { Link } from 'react-router-dom';
import './Font1.css';
import EmailVerification from './EmailVerification';
import axios from "axios";

const Signup = ({ onClose, onSwitch }) => {

  const [step, setStep] = useState(1);
  const [username, setUsername] = useState('');
  const [fullName, setFullName] = useState('');
  const [password, setPassword] = useState('');
  const [email, setEmail] = useState('');
  const [mobileNumber, setMobileNumber] = useState('');
  const [acceptTerms, setAcceptTerms] = useState(false);
  const [formErrors, setFormErrors] = useState({});
  const [userRole, setUserRole] = useState();
  const signUpData = {
    fullName,
    username,
    password,
    email,
    mobileNumber,
    userRole: "STUDENT"
  }
  const validateForm = () => {
    const errors = {};

    // Validate username
    if (!username.trim()) {
      errors.username = 'Username is required';
    }

    // Validate fullname
    if (!fullName.trim()) {
      errors.fullName = 'Fullname is required';
    }

    // Validate password
    if (!password.trim()) {
      errors.password = 'Password is required';
    }

    // Validate email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email.trim() || !emailRegex.test(email)) {
      errors.email = 'Enter a valid email address';
    }

    // Validate phone number
    const phoneRegex = /^\+?[0-9]{10,}$/;
    if (!mobileNumber.trim() || !phoneRegex.test(mobileNumber)) {
      errors.mobileNumber = 'Enter a valid phone number';
    }

    // Validate terms and conditions
    if (!acceptTerms) {
      errors.acceptTerms = 'You must accept terms and conditions';
    }

    return errors;
  };


  const handleEmailVerify = (e) => {
    e.preventDefault();
    const errors = validateForm();

    axios.post('http://192.168.0.138:8080/register', signUpData, {
      headers: {
        'Content-Type': 'application/json'
      }
    })
      .then(function (response) {
        // imgCnt = response.data;
        // console.log(imgCnt);
        console.log(response);
      })
      .catch(function (error) {
        console.log(error);
      });
    if (Object.keys(errors).length === 0) {
      // If no errors, proceed with form submission
      // You can call an API here or perform other actions
      console.log('Form submitted successfully!');

      setStep(2);
      console.log(signUpData);
    } else {
      // If there are errors, show an alert message
      const errorMessage = Object.values(errors).join('\n');
      window.alert(errorMessage);

    }
  };

  const [isPassShow, setPassShow] = useState(false);
  const [passType, setPassType] = useState('password');

  const passShowHide = (bool) => {
    setPassShow(!bool);
    if (passType == "password") {
      setPassType('text');
    } else {
      setPassType('password');
    }

  };

  return (
    <>
      <div className="overlay">
        <div className="login-form">
          <button className="close-button" onClick={onClose}>
            &times;
          </button>
          <div className="box2">
            {step === 1 && (
              <form>
                <h1>SignUp and Start Learning!</h1>

                <div className='input-icons'>
                  <i className='fa fa-user icon8' />
                  <input
                    className='opt input-field'
                    type='text'
                    placeholder='Enter username'
                    onChange={(e) => setUsername(e.target.value)}
                  />

                </div>

                <div className='input-icons'>
                  <i className='fa fa-user icon8' />
                  <input
                    className='opt input-field'
                    type='text'
                    placeholder='Enter fullname'
                    onChange={(e) => setFullName(e.target.value)}
                  />
                </div>

                <div className='input-icons'>
                  <i
                    onClick={() => { passShowHide(isPassShow) }}
                    className={`fa ${isPassShow ? 'fa-eye' : 'fa-eye-slash'} icon8 icon8-1`}
                  />
                  <input
                    className='opt input-field'
                    type={passType}
                    placeholder='Enter password'
                    onChange={(e) => setPassword(e.target.value)}
                  />
                </div>

                <div className='input-icons'>
                  <i className='fa fa-envelope icon8' />
                  <input
                    className='opt input-field'
                    type='email'
                    placeholder='Enter email'
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>

                <div className='input-icons'>
                  <i className='fa fa-mobile icon8' />
                  <input
                    className='opt input-field'
                    type='text'
                    placeholder='+91 9999999999'
                    onChange={(e) => setMobileNumber(e.target.value)}
                  />
                </div>

                <div className='terms-and-conditions'>
                  <input type='checkbox' id='accept-terms' onChange={(e) => setAcceptTerms(e.target.value)} />
                  <label> I accept terms and conditions</label>
                </div>

                <button type='submit' className='opt2' id='btn2' onClick={handleEmailVerify} >
                  SignUp!
                </button>


                <Link onClick={onSwitch} className='forgot2'>
                  Login
                </Link>
              </form>
            )}
            {step === 2 && (
              <EmailVerification
                onClose={() => {
                  setStep(1); // Move back to the Signup step when closing EmailVerification
                  onClose();
                }}
              />
            )}
          </div>
        </div>
      </div>
      {/* )} */}
    </>
  );
};

export default Signup;
