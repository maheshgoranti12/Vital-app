import React, { useState } from 'react';
import './Login.css';
import { Link } from 'react-router-dom';
import './Font1.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUserTie } from '@fortawesome/free-solid-svg-icons';

const Login = ({ onClose, onSwitch }) => {
  const [isPassShow, setPassShow] = useState(false);
  const [passType, setPassType] = useState('password');

  const passShowHide = (bool) => {
    setPassShow(!bool);
    if(passType == "password"){
      setPassType('text');
    }else{
      setPassType('password');
    }
    
  };
  const user= <FontAwesomeIcon icon={faUserTie} />;
  return (
    <>
     <div className="overlay">
        <div className="login-form">
          <button className="close-button" onClick={onClose}>
            &times;
          </button>
          <div className="box">
            <form action="/">
              <h1>Login into your account!</h1>
              <div className='input-icons'>
                <i className='fa fa-user icon9' />
              <input type="text" className='opt8' id='name' placeholder='Enter Username' /> </div>
              <div className='input-icons'>
                <i
                  onClick={()=>{passShowHide(isPassShow)}}
                  className={`fa ${isPassShow ? 'fa-eye' : 'fa-eye-slash'} icon9 icon9-1`}
                />
              <input type={passType} className='opt8' id='pass' placeholder='Enter Password' /></div>
              <button type='submit' className='opt' id='btn'>Login!</button>
              <a href="/" className='forgot' id='for-pass'>Forgot Password</a>
              <Link onClick={onSwitch} className='forgot' id='for-sign'>Sign up</Link>
              <a href="/" className='forgot' id='for-name'>Forgot Username</a>
            </form>
          </div>
        </div>
      </div>
    </>
  );
}

export default Login;
