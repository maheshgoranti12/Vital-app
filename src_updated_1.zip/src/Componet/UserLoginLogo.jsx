import React from 'react';
import './UserLoginLogo.css';
const UserLoginLogo = () => {
   
  return (
    <>
      <div className="user_login">

      </div>
    </>
  );
}

export default UserLoginLogo;
